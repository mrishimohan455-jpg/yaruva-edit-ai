# YARUVA — New AI Creative Studio

Fresh build. Set `OPENAI_API_KEY` in Vercel Environment Variables. Never place the key in browser code.

Features: AI image editing endpoint, image-to-video endpoint, mobile-first editor, filters, adjustments and export.
