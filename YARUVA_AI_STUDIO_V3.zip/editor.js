let sourceData="", currentFilter="none", effect="none";
const $=id=>document.getElementById(id);
const fileInput=$("fileInput"), preview=$("preview"), placeholder=$("placeholder"), canvas=$("canvas");
if(fileInput) fileInput.addEventListener("change",e=>loadImage(e.target.files[0]));
function loadImage(file){if(!file)return;const r=new FileReader();r.onload=()=>{sourceData=r.result;preview.src=sourceData;preview.hidden=false;placeholder.hidden=true;updateLook();};r.readAsDataURL(file)}
document.querySelectorAll(".suggestions button").forEach(b=>b.onclick=()=>{$("prompt").value=b.dataset.prompt});
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));document.querySelectorAll(".panel").forEach(x=>x.classList.remove("active"));b.classList.add("active");$(b.dataset.tab).classList.add("active")});
["brightness","contrast","saturation"].forEach(id=>$(id)?.addEventListener("input",updateLook));
document.querySelectorAll("[data-filter]").forEach(b=>b.onclick=()=>{currentFilter=b.dataset.filter;updateLook()});
document.querySelectorAll("[data-effect]").forEach(b=>b.onclick=()=>{effect=b.dataset.effect;updateLook()});
function updateLook(){if(!preview.src)return;let b=$("brightness").value,c=$("contrast").value,s=$("saturation").value;let f="brightness("+b+"%) contrast("+c+"%) saturate("+s+"%)";if(currentFilter==="cinematic")f+=" sepia(10%) contrast(115%)";if(currentFilter==="vivid")f+=" saturate(135%) contrast(108%)";if(currentFilter==="mono")f+=" grayscale(100%)";if(currentFilter==="warm")f+=" sepia(20%)";if(currentFilter==="cool")f+=" hue-rotate(12deg)";if(effect==="soft")f+=" brightness(105%)";preview.style.filter=f}
$("aiBtn")?.addEventListener("click",async()=>{if(!sourceData)return setStatus("Upload an image first.");let prompt=$("prompt").value.trim();if(!prompt)return setStatus("Tell YARUVA what to change.");setStatus("YARUVA AI is creating your edit…");$("aiBtn").disabled=true;try{const r=await fetch("/api/edit-image",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({image:sourceData,prompt})});const d=await r.json();if(!r.ok)throw Error(d.error||"AI edit failed");beforeImage=sourceData; preview.src=d.image; sourceData=d.image; $("compareBar").hidden=false; setStatus("AI edit complete. Compare Before / After.");}catch(e){setStatus(e.message)}finally{$("aiBtn").disabled=false}});
async function createVideo(){if(!sourceData)return setVideoStatus("Upload an image first.");let prompt=$("videoPrompt").value.trim()||"Create a cinematic, natural camera movement from this image.";setVideoStatus("Starting video generation…");$("videoBtn").disabled=true;try{const r=await fetch("/api/video",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prompt,image:sourceData})});const d=await r.json();if(!r.ok)throw Error(d.error||"Video generation failed");setVideoStatus("Video job started. Job ID: "+d.id);}catch(e){setVideoStatus(e.message)}finally{$("videoBtn").disabled=false}}
$("videoBtn")?.addEventListener("click",createVideo);
$("exportBtn")?.addEventListener("click",()=>{if(!preview.src)return alert("Upload an image first.");const a=document.createElement("a");a.href=preview.src;a.download="yaruva-creation.png";a.click();saveProject()});
function setStatus(x){$("status").textContent=x} function setVideoStatus(x){$("videoStatus").textContent=x}
const mode=new URLSearchParams(location.search).get("mode");if(mode==="video")document.querySelector('[data-tab="video"]')?.click();
canvas?.addEventListener("dragover",e=>{e.preventDefault();canvas.style.borderColor="#666"});
canvas?.addEventListener("dragleave",()=>canvas.style.borderColor="");
canvas?.addEventListener("drop",e=>{e.preventDefault();canvas.style.borderColor="";loadImage(e.dataTransfer.files[0])});
async function pollVideo(id){
  setVideoStatus("Rendering video…");
  for(let i=0;i<60;i++){
    await new Promise(r=>setTimeout(r,5000));
    const r=await fetch("/api/video-status?id="+encodeURIComponent(id)); const d=await r.json();
    if(d.status==="completed"){setVideoStatus("Video ready."); const a=document.createElement("a");a.href="/api/video-content?id="+encodeURIComponent(id);a.textContent=" Preview / play video";a.target="_blank";a.style.color="#fff";$("videoStatus").appendChild(a);return}
    if(d.status==="failed"||d.status==="cancelled"){setVideoStatus("Video generation failed.");return}
  }
  setVideoStatus("Video is still rendering. Check again later.");
}
const oldCreateVideo=createVideo;
createVideo=async function(){
  if(!sourceData)return setVideoStatus("Upload an image first.");
  let prompt=$("videoPrompt").value.trim()||"Create a cinematic, natural camera movement from this image.";
  setVideoStatus("Starting video generation…");$("videoBtn").disabled=true;
  try{const r=await fetch("/api/video",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prompt,image:sourceData})});
    const d=await r.json();if(!r.ok)throw Error(d.error||"Video generation failed");
    setVideoStatus("Video job started.");pollVideo(d.id);
  }catch(e){setVideoStatus(e.message)}finally{$("videoBtn").disabled=false}
}

const aiButtons=document.querySelectorAll("[data-ai]");
aiButtons.forEach(btn=>btn.addEventListener("click",()=>{$("prompt").value=btn.dataset.ai;$("aiBtn").click()}));
let beforeImage=window.beforeImage||"";
$("showBefore")?.addEventListener("click",()=>{if(!beforeImage)return;preview.src=beforeImage;$("showBefore").classList.add("selected");$("showAfter").classList.remove("selected")});
$("showAfter")?.addEventListener("click",()=>{if(!sourceData)return;preview.src=sourceData;$("showAfter").classList.add("selected");$("showBefore").classList.remove("selected")});

function saveProject(){try{let p=JSON.parse(localStorage.getItem("yaruvaProjects")||"[]");p.unshift({title:$("prompt").value.trim()||"AI Creation",image:sourceData,date:new Date().toLocaleString()});p=p.slice(0,12);localStorage.setItem("yaruvaProjects",JSON.stringify(p))}catch(e){}}
